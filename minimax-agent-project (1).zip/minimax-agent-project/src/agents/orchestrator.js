/**
 * 任务编排 Agent
 * 负责将复杂任务分解为可执行的子任务
 */

import LLMClient from '../core/llm.js';
import { log } from '../utils/tools.js';

class OrchestratorAgent {
  constructor(llmClient) {
    if (!(llmClient instanceof LLMClient)) {
      throw new Error('OrchestratorAgent requires LLMClient instance');
    }
    this.llm = llmClient;
    this.subAgents = new Map();
    this.taskHistory = [];
  }

  /**
   * 注册子 Agent
   * @param {string} name - Agent 名称
   * @param {Object} agent - Agent 实例
   */
  registerAgent(name, agent) {
    this.subAgents.set(name, agent);
    log('info', `已注册子Agent: ${name}`);
  }

  /**
   * 获取所有已注册的 Agent 名称
   * @returns {Array<string>} Agent 名称列表
   */
  getRegisteredAgents() {
    return Array.from(this.subAgents.keys());
  }

  /**
   * 制定任务执行计划
   * @param {string} userRequest - 用户请求
   * @returns {Promise<Object>} 任务计划
   */
  async planTask(userRequest) {
    const availableAgents = this.getRegisteredAgents();

    const systemPrompt = `你是任务编排专家，负责将复杂任务分解为可执行的子任务。

可用子Agent列表：
${availableAgents.map(name => `- ${name}`).join('\n')}

请分析用户请求，制定执行计划。计划应包含多个有序步骤，每个步骤指定：
- action: 动作描述
- agent: 调用的Agent名称
- params: 传递给Agent的参数
- requiresVerification: 是否需要验证结果

请以JSON格式输出计划：
{
  "goal": "总体目标",
  "steps": [
    {
      "action": "动作描述",
      "agent": "agent名称",
      "params": {},
      "requiresVerification": true/false
    }
  ]
}`;

    const messages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userRequest },
    ];

    try {
      const response = await this.llm.chatWithReasoning(messages);
      const plan = JSON.parse(response.content);

      log('info', '任务计划已生成', { steps: plan.steps?.length || 0 });
      return plan;
    } catch (error) {
      log('error', '制定计划失败', { error: error.message });
      throw error;
    }
  }

  /**
   * 执行任务计划
   * @param {Object} taskPlan - 任务计划
   * @returns {Promise<Array>} 执行结果
   */
  async executeTask(taskPlan) {
    const results = [];

    for (const step of taskPlan.steps) {
      log('info', `执行步骤: ${step.action}`);

      const agent = this.subAgents.get(step.agent);
      if (!agent) {
        const error = new Error(`未知Agent: ${step.agent}`);
        log('error', error.message);
        throw error;
      }

      try {
        const result = await agent.execute(step.params);
        results.push({
          step: step.action,
          agent: step.agent,
          success: true,
          data: result,
        });

        // 验证结果
        if (step.requiresVerification && !result.success) {
          log('warn', '验证失败，尝试重新规划...');
          const adjustedPlan = await this.planTask(
            `调整计划：${step.action} 失败，原因：${result.error}`
          );
          const adjustedResults = await this.executeTask(adjustedPlan);
          return [...results, ...adjustedResults];
        }
      } catch (error) {
        log('error', `步骤执行失败: ${step.action}`, { error: error.message });
        results.push({
          step: step.action,
          agent: step.agent,
          success: false,
          error: error.message,
        });
      }
    }

    // 记录执行历史
    this.taskHistory.push({
      plan: taskPlan,
      results: results,
      timestamp: new Date().toISOString(),
    });

    return results;
  }

  /**
   * 获取执行历史
   * @param {number} limit - 返回记录数
   */
  getHistory(limit = 10) {
    return this.taskHistory.slice(-limit);
  }

  /**
   * 清除执行历史
   */
  clearHistory() {
    this.taskHistory = [];
  }
}

export default OrchestratorAgent;
