/**
 * 测试执行 Agent
 * 自动运行单元测试，验证重构正确性
 */

import { log, retry } from '../utils/tools.js';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

class TesterAgent {
  constructor(options = {}) {
    this.testCommand = options.testCommand || 'npm test';
    this.coverageThreshold = options.coverageThreshold || 80;
  }

  /**
   * 运行测试
   * @param {string} command - 测试命令
   * @returns {Promise<Object>} 测试结果
   */
  async runTest(command = this.testCommand) {
    try {
      log('info', `执行测试命令: ${command}`);

      const { stdout, stderr } = await execAsync(command, {
        timeout: 300000, // 5分钟超时
        maxBuffer: 10 * 1024 * 1024, // 10MB buffer
      });

      return this.parseTestOutput(stdout, stderr);
    } catch (error) {
      return this.parseTestOutput(error.stdout || '', error.stderr || '', true);
    }
  }

  /**
   * 解析测试输出
   * @param {string} stdout - 标准输出
   * @param {string} stderr - 标准错误
   * @param {boolean} failed - 是否失败
   * @returns {Object} 解析结果
   */
  parseTestOutput(stdout, stderr, failed = false) {
    const output = stdout + stderr;

    // 提取测试统计
    const passMatch = output.match(/Tests:\s+(\d+)\s+passed/);
    const failMatch = output.match(/(\d+)\s+failed/);
    const durationMatch = output.match(/Time:\s+([\d.]+)s/);
    const coverageMatch = output.match(/All files[^|]*\|\s*([\d.]+)\s*%/);

    const passCount = passMatch ? parseInt(passMatch[1]) : 0;
    const failCount = failMatch ? parseInt(failMatch[1]) : (failed ? 1 : 0);
    const duration = durationMatch ? parseFloat(durationMatch[1]) : 0;
    const coverage = coverageMatch ? parseFloat(coverageMatch[1]) : null;

    return {
      success: failCount === 0,
      passed: passCount,
      failed: failCount,
      duration,
      coverage,
      output: output.substring(0, 5000), // 限制输出长度
    };
  }

  /**
   * 执行验证任务
   * @param {Object} params - 任务参数
   * @returns {Promise<Object>} 验证结果
   */
  async execute(params) {
    const { refactorResults, retryCount = 2 } = params;

    if (!refactorResults || refactorResults.length === 0) {
      return { success: false, error: '没有可验证的重构结果' };
    }

    log('info', `开始验证 ${refactorResults.length} 个文件的重构`);

    // 运行测试（带重试）
    let testResult;
    for (let i = 0; i <= retryCount; i++) {
      testResult = await this.runTest();
      if (testResult.success) break;

      if (i < retryCount) {
        log('warn', `测试失败，${retryCount - i}秒后重试...`);
        await new Promise(r => setTimeout(r, (i + 1) * 1000));
      }
    }

    // 检查覆盖率
    let coveragePass = true;
    if (testResult.coverage !== null) {
      coveragePass = testResult.coverage >= this.coverageThreshold;
      log('info', `覆盖率: ${testResult.coverage}% (阈值: ${this.coverageThreshold}%)`);
    }

    return {
      success: testResult.success && coveragePass,
      testResult,
      coveragePass,
      summary: {
        allPassed: testResult.success,
        coverageMet: coveragePass,
        totalTests: testResult.passed + testResult.failed,
        failedTests: testResult.failed,
      },
    };
  }
}

export default TesterAgent;
