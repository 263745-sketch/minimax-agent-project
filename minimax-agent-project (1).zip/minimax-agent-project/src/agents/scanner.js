/**
 * 代码扫描 Agent
 * 自动分析代码库，识别技术债务和架构违规
 */

import LLMClient from '../core/llm.js';
import { log } from '../utils/tools.js';

/**
 * 默认扫描规则
 */
const DEFAULT_RULES = [
  '函数过长（超过100行）',
  '圈复杂度过高（超过10）',
  '重复代码块（相似度>80%）',
  '命名不规范',
  '缺少注释的关键逻辑',
  '硬编码常量',
  '未处理的异常',
  '资源未释放',
  '安全漏洞（如SQL注入、 XSS）',
  '性能问题（如N+1查询）',
];

/**
 * 忽略文件模式
 */
const DEFAULT_IGNORE_PATTERNS = [
  /node_modules/,
  /dist/,
  /build/,
  /\.git/,
  /coverage/,
  /.*\.test\.js$/,
  /.*\.spec\.js$/,
];

class ScannerAgent {
  constructor(llmClient) {
    if (!(llmClient instanceof LLMClient)) {
      throw new Error('ScannerAgent requires LLMClient instance');
    }
    this.llm = llmClient;
    this.rules = DEFAULT_RULES;
  }

  /**
   * 更新扫描规则
   * @param {Array<string>} rules - 新的规则列表
   */
  setRules(rules) {
    this.rules = rules;
    log('info', '扫描规则已更新', { count: rules.length });
  }

  /**
   * 扫描单个文件
   * @param {Object} file - 文件对象 {path, content}
   * @returns {Promise<Object>} 扫描结果
   */
  async scanFile(file) {
    const rulesText = this.rules.map((r, i) => `${i + 1}. ${r}`).join('\n');

    const scanPrompt = `你是代码质量分析专家。请分析以下代码，识别技术债务。

扫描规则：
${rulesText}

文件路径：${file.path}

代码内容：
\`\`\`${file.content}\`\`\`

请输出JSON格式的扫描结果：
{
  "file": "${file.path}",
  "issues": [
    {
      "line": 行号,
      "severity": "high|medium|low",
      "type": "问题类型",
      "description": "问题描述",
      "suggestion": "修复建议"
    }
  ]
}`;

    try {
      const response = await this.llm.chat([
        { role: 'system', content: '你是一个专业的代码质量分析工具，只输出JSON。' },
        { role: 'user', content: scanPrompt },
      ]);

      return JSON.parse(response.content);
    } catch (error) {
      log('error', `扫描文件失败: ${file.path}`, { error: error.message });
      return { file: file.path, issues: [], error: error.message };
    }
  }

  /**
   * 批量扫描文件
   * @param {Array} files - 文件数组
   * @returns {Promise<Array>} 扫描结果
   */
  async scanFiles(files) {
    log('info', `开始批量扫描 ${files.length} 个文件`);

    const results = await Promise.all(
      files.map(file => this.scanFile(file))
    );

    return results;
  }

  /**
   * 执行扫描任务
   * @param {Object} params - 任务参数
   * @returns {Promise<Object>} 扫描结果
   */
  async execute(params) {
    const {
      codebase,
      rules = this.rules,
      ignorePatterns = DEFAULT_IGNORE_PATTERNS,
      parallel = true,
    } = params;

    // 更新规则
    if (rules !== this.rules) {
      this.setRules(rules);
    }

    // 过滤文件
    const files = this.filterFiles(codebase, ignorePatterns);
    log('info', `过滤后待扫描文件: ${files.length} 个`);

    // 扫描
    let scanResults;
    if (parallel) {
      scanResults = await this.scanFiles(files);
    } else {
      scanResults = [];
      for (const file of files) {
        const result = await this.scanFile(file);
        scanResults.push(result);
      }
    }

    // 合并结果
    return this.mergeResults(scanResults);
  }

  /**
   * 过滤文件
   * @param {Array} files - 文件数组
   * @param {Array<RegExp>} patterns - 忽略模式
   * @returns {Array} 过滤后的文件
   */
  filterFiles(files, patterns) {
    return files.filter(file => {
      return !patterns.some(p => p.test(file.path));
    });
  }

  /**
   * 合并扫描结果
   * @param {Array} results - 扫描结果数组
   * @returns {Object} 合并后的结果
   */
  mergeResults(results) {
    const allIssues = results.flatMap(r => r.issues || []);

    const summary = {
      total: allIssues.length,
      high: allIssues.filter(i => i.severity === 'high').length,
      medium: allIssues.filter(i => i.severity === 'medium').length,
      low: allIssues.filter(i => i.severity === 'low').length,
    };

    // 按严重程度排序
    const severityOrder = { high: 0, medium: 1, low: 2 };
    allIssues.sort((a, b) =>
      severityOrder[a.severity] - severityOrder[b.severity]
    );

    return {
      success: true,
      issues: allIssues,
      summary,
      fileCount: results.length,
    };
  }
}

export default ScannerAgent;
