/**
 * 重构生成 Agent
 * 基于规则生成符合架构规范的代码修改
 */

import LLMClient from '../core/llm.js';
import { log } from '../utils/tools.js';

class RefactorAgent {
  constructor(llmClient) {
    if (!(llmClient instanceof LLMClient)) {
      throw new Error('RefactorAgent requires LLMClient instance');
    }
    this.llm = llmClient;
  }

  /**
   * 生成单个文件的重构方案
   * @param {Object} file - 文件对象
   * @param {Array} issues - 问题列表
   * @returns {Promise<Object>} 重构方案
   */
  async generateRefactor(file, issues) {
    const issuesText = issues.map((issue, i) =>
      `${i + 1}. 第${issue.line}行: ${issue.description}\n   建议: ${issue.suggestion}`
    ).join('\n');

    const prompt = `你是代码重构专家。基于以下问题分析，为文件生成重构方案。

文件路径：${file.path}

发现的问题：
${issuesText}

代码内容：
\`\`\`${file.content}\`\`\`

请输出JSON格式的重构方案：
{
  "file": "${file.path}",
  "changes": [
    {
      "type": "add|remove|modify",
      "line": 行号,
      "original": "原始代码",
      "modified": "修改后代码",
      "reason": "修改原因"
    }
  ],
  "summary": "重构总结"
}`;

    try {
      const response = await this.llm.chatWithReasoning([
        { role: 'system', content: '你是一个专业的代码重构专家，输出JSON格式。' },
        { role: 'user', content: prompt },
      ]);

      return {
        ...JSON.parse(response.content),
        reasoning: response.reasoning,
      };
    } catch (error) {
      log('error', `生成重构方案失败: ${file.path}`, { error: error.message });
      return { file: file.path, changes: [], error: error.message };
    }
  }

  /**
   * 执行重构任务
   * @param {Object} params - 任务参数
   * @returns {Promise<Object>} 重构结果
   */
  async execute(params) {
    const { scanResults, targetFiles } = params;

    if (!scanResults || scanResults.length === 0) {
      return { success: false, error: '没有可重构的问题' };
    }

    log('info', `开始生成 ${scanResults.length} 个文件的重构方案`);

    // 按文件分组问题
    const issuesByFile = new Map();
    for (const result of scanResults) {
      const issues = result.issues || [];
      if (issues.length > 0) {
        const existing = issuesByFile.get(result.file) || [];
        issuesByFile.set(result.file, [...existing, ...issues]);
      }
    }

    // 选择要处理的文件
    const filesToRefactor = targetFiles || Array.from(issuesByFile.keys());

    // 生成重构方案
    const refactorResults = [];
    for (const file of filesToRefactor) {
      const issues = issuesByFile.get(file);
      if (issues) {
        const result = await this.generateRefactor(
          { path: file.path, content: file.content },
          issues
        );
        refactorResults.push(result);
      }
    }

    // 计算统计
    const totalChanges = refactorResults.reduce(
      (sum, r) => sum + (r.changes?.length || 0), 0
    );

    return {
      success: true,
      results: refactorResults,
      summary: {
        filesProcessed: refactorResults.length,
        totalChanges,
      },
    };
  }
}

export default RefactorAgent;
