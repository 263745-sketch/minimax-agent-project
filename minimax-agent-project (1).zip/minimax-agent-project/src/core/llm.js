/**
 * MiniMax 大模型 API 封装
 * 提供对话、长链推理等核心能力
 */

import MiniMax from '@minimax-api/sdk';

class LLMClient {
  constructor(apiKey, model = 'abab6.5s-chat') {
    if (!apiKey) {
      throw new Error('MINIMAX_API_KEY is required');
    }
    this.client = new MiniMax(apiKey);
    this.model = model;
  }

  /**
   * 基础对话接口
   * @param {Array} messages - 消息数组 [{role: 'user'|'system'|'assistant', content: string}]
   * @param {Object} options - 配置选项
   * @returns {Promise<Object>} 响应消息
   */
  async chat(messages, options = {}) {
    try {
      const response = await this.client.chat.create({
        model: this.model,
        messages: messages,
        temperature: options.temperature ?? 0.7,
        max_tokens: options.maxTokens ?? 4096,
      });

      return response.choices[0].message;
    } catch (error) {
      console.error('[LLMClient] Chat Error:', error.message);
      throw error;
    }
  }

  /**
   * 长链推理模式
   * 适用于复杂任务的多步推理决策
   * @param {Array} messages - 消息数组
   * @param {Object} options - 配置选项
   * @returns {Promise<Object>} 包含内容和推理过程
   */
  async chatWithReasoning(messages, options = {}) {
    try {
      const response = await this.client.chat.create({
        model: this.model,
        messages: messages,
        temperature: options.temperature ?? 0.3,
        max_tokens: options.maxTokens ?? 8192,
        reasoning_template: 'detailed',
      });

      return {
        content: response.choices[0].message.content,
        reasoning: response.choices[0].message.reasoning || [],
      };
    } catch (error) {
      console.error('[LLMClient] Reasoning Error:', error.message);
      throw error;
    }
  }

  /**
   * 流式对话
   * @param {Array} messages - 消息数组
   * @param {Function} onChunk - 流式回调
   */
  async chatStream(messages, onChunk) {
    const stream = await this.client.chat.create({
      model: this.model,
      messages: messages,
      stream: true,
    });

    for await (const chunk of stream) {
      onChunk(chunk.choices[0].delta);
    }
  }

  /**
   * 批量处理请求
   * @param {Array} requests - 请求数组
   * @returns {Promise<Array>} 响应数组
   */
  async batchChat(requests) {
    return Promise.all(
      requests.map(req => this.chat(req.messages, req.options))
    );
  }
}

export default LLMClient;
