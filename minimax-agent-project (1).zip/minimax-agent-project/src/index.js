/**
 * MiniMax Agent 项目入口
 * 演示多 Agent 协作的代码重构自动化流程
 */

import dotenv from 'dotenv';
import LLMClient from './core/llm.js';
import OrchestratorAgent from './agents/orchestrator.js';
import ScannerAgent from './agents/scanner.js';
import RefactorAgent from './agents/refactor.js';
import TesterAgent from './agents/tester.js';
import { log } from './utils/tools.js';

// 加载环境变量
dotenv.config();

/**
 * 主函数
 */
async function main() {
  log('info', '='.repeat(50));
  log('info', '🚀 MiniMax Agent 代码重构自动化系统启动');
  log('info', '='.repeat(50));

  // 检查 API Key
  if (!process.env.MINIMAX_API_KEY) {
    log('error', '错误: MINIMAX_API_KEY 未设置');
    log('info', '请在 .env 文件中设置您的 MiniMax API Key');
    process.exit(1);
  }

  try {
    // 1. 初始化 LLM 客户端
    log('info', '1. 初始化 LLM 客户端...');
    const llm = new LLMClient(process.env.MINIMAX_API_KEY);
    log('info', '   模型: abab6.5s-chat');

    // 2. 初始化 Agent 系统
    log('info', '2. 初始化 Agent 系统...');
    const orchestrator = new OrchestratorAgent(llm);
    const scanner = new ScannerAgent(llm);
    const refactor = new RefactorAgent(llm);
    const tester = new TesterAgent();

    // 3. 注册子 Agent
    log('info', '3. 注册子 Agents...');
    orchestrator.registerAgent('scanner', scanner);
    orchestrator.registerAgent('refactor', refactor);
    orchestrator.registerAgent('tester', tester);

    // 4. 演示任务
    const demoTask = `
      请分析当前代码库中的技术债务，
      生成重构方案，创建 PR，
      并验证测试通过。
    `;

    log('info', '4. 制定执行计划...');
    const plan = await orchestrator.planTask(demoTask);
    console.log('\n📋 执行计划:');
    console.log(JSON.stringify(plan, null, 2));

    // 5. 执行任务
    log('info', '5. 开始执行任务...');
    const results = await orchestrator.executeTask(plan);

    // 6. 输出结果
    log('info', '='.repeat(50));
    log('info', '✅ 执行完成!');
    log('info', '='.repeat(50));
    console.log('\n📊 结果汇总:');
    console.log(JSON.stringify(results, null, 2));

    return results;
  } catch (error) {
    log('error', '执行失败', { error: error.message });
    throw error;
  }
}

// 导出模块
export { LLMClient, OrchestratorAgent, ScannerAgent, RefactorAgent, TesterAgent };

// 运行主函数
main().catch(error => {
  console.error('Fatal error:', error);
  process.exit(1);
});
