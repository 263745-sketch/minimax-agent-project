/**
 * 工具函数库
 * 提供通用工具能力
 */

/**
 * 格式化时间戳
 * @param {Date|number} date - 日期对象或时间戳
 * @returns {string} 格式化日期字符串
 */
export function formatTimestamp(date = new Date()) {
  const d = date instanceof Date ? date : new Date(date);
  return d.toISOString().replace('T', ' ').substring(0, 19);
}

/**
 * 日志输出
 * @param {string} level - 日志级别
 * @param {string} message - 日志消息
 * @param {Object} meta - 附加数据
 */
export function log(level, message, meta = {}) {
  const timestamp = formatTimestamp();
  const logEntry = {
    timestamp,
    level,
    message,
    ...meta,
  };
  console.log(`[${timestamp}] [${level.toUpperCase()}] ${message}`,
    Object.keys(meta).length > 0 ? meta : ''
  );
}

/**
 * 防抖函数
 * @param {Function} fn - 要防抖的函数
 * @param {number} delay - 延迟毫秒
 */
export function debounce(fn, delay = 300) {
  let timeoutId;
  return function (...args) {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => fn.apply(this, args), delay);
  };
}

/**
 * 节流函数
 * @param {Function} fn - 要节流的函数
 * @param {number} limit - 间隔毫秒
 */
export function throttle(fn, limit = 300) {
  let inThrottle;
  return function (...args) {
    if (!inThrottle) {
      fn.apply(this, args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

/**
 * 重试函数
 * @param {Function} fn - 要重试的函数
 * @param {number} maxRetries - 最大重试次数
 * @param {number} delay - 重试延迟
 */
export async function retry(fn, maxRetries = 3, delay = 1000) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i === maxRetries - 1) throw error;
      log('warn', `重试 ${i + 1}/${maxRetries}: ${error.message}`);
      await new Promise(r => setTimeout(r, delay * (i + 1)));
    }
  }
}

/**
 * 深度克隆对象
 * @param {Object} obj - 要克隆的对象
 */
export function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

/**
 * 延迟执行
 * @param {number} ms - 延迟毫秒
 */
export function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
